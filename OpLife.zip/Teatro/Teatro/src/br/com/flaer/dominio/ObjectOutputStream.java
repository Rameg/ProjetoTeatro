package br.com.flaer.dominio;

public interface ObjectOutputStream {

	void writeObject(ArrayList clientes);

	void writeObject11(Usuario[] x1);

	void close();

	void writeObject1(Usuario[] x1);

	void writeObject(Usuario[] x1);

}

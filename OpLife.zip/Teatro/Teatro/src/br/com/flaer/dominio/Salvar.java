package br.com.flaer.dominio;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;


public class Salvar {

	/**
	 * Metodo para salvar o cadastro 
	 * @param arquivo String com nome do arquivo
	 * @param conteudo O que ser� salvo
	 * @return Mensagem de status
	 */
	public String salvarCadastro(String arquivo, String conteudo){
		
		FileWriter arq;
		String msg;
		
		try {
				
			arq = new FileWriter(arquivo,true);
			PrintWriter gravarArq = new PrintWriter(arq);
		    gravarArq.write(conteudo);
		    gravarArq.close();
		    msg = "SALVO COM SUCESSO !";

		} catch (IOException e) {
			msg = "NUNCA FOI VISTO SALVAR O ARQUIVO";
		}
		
		return msg;
		
	}

	/**
	 * Faz um teste se o arquivo existe
	 * @param arquivo String com nome do arquivo
	 * @return Mensagem de status
	 */
	public boolean verificarArquivoJaExistente(String arquivo) {
		
		boolean existe;
		
		try {
			FileReader fr = new FileReader(arquivo);
			BufferedReader br = new BufferedReader(fr);
			br.close();
			fr.close();
			existe = true;
		} catch (FileNotFoundException e) {
			existe = false;
		} catch (IOException e){
			existe = false;
		} catch (NullPointerException e){
			existe = false;
		}
		
		return existe;
		
	}
	
}

package br.com.flaer.dominio;
import java.io.Serializable;



	public class Cadeira implements Serializable {
	    /**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		static Usuario[] x1 = new Usuario[100];
	    
	    
	    static void iniciaCadeiras(Usuario[] usua, Usuario[] x1){
	        Cadeira.x1 = x1;
	    }
	    
	    static boolean alocaLugar(int lugar, Usuario usu){
	        
	        if(x1[lugar-1] == null){
	            usu.setPosicao(lugar);
	            Cadeira.x1[lugar-1] = usu;
	            
	        return true;
	        }
	        return false;
	    }
	    
	    static boolean desalocaLugar(int lugar){
	        if(x1[lugar-1] != null){
	            Usuario use = x1[lugar-1];
	            use.setPosicao(0);
	            x1[lugar-1] = null;
	            return true;
	        }
	        
	        return false;
	    }
	    
	    static void emptySpot(){
	        int a = 0;
	        for (int i = 0; i < x1.length; i++) {
	            if(x1[i] == null){
	                System.out.println("CADEIRA "+ (i+1) + " DISPONIVEL");
	                a++;
	            }
	           }
	        if(a==0){
	            System.out.println("INFELIMENTE NOSSA CAPACIDADE MAXIMA FOI ATINGIDA\n VOLTE MAIS CEDO DA PROXIMA SEU VACIL�O");
	        }
	    }
	    
	    static void crowdedSpot(){
	        int a = 0;
	        for (int i = 0; i < x1.length; i++) {
	            if(x1[i] != null){
	                System.out.println("CADEIRA "+ (i+1) + " INDISPONIVEL");
	                a++;
	            }
	           }
	        if(a==0){
	            System.out.println("Tudo Livre");
	        }
	    }
	    
	    
	}

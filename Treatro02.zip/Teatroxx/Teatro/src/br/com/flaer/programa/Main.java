
package br.com.flaer.programa;

import br.com.flaer.dominio.Cadeira;
import br.com.flaer.dominio.Menu;

public class Main {
    public static void main(String[] args) 
    {
            Cadeira cad = new Cadeira ();
            Menu.exibeMenu();
            Menu.receberOpc(cad);
            
            while(true){
                
                Menu.exibeMenu();
                Menu.receberOpc(cad);
            }
    }
}

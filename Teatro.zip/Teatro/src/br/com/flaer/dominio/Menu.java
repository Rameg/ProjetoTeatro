package br.com.flaer.dominio;

/**
 * @author aluno
 *
 */
public class Menu {

	/**
	 * 
	 */
	public Menu() {				
		
	}
	
	public void exibeMenu() {
		System.out.println("##################### #");
		System.out.println("# 1- Ocupar  Lugar      #");
		System.out.println("# 2- Desocupar Lugar       #");
		System.out.println("# 3- Listar cadeiras livres  #");
		System.out.println("# 4- Listar cadeiras ocupadas #");
		System.out.println("# 5- Encerrar Programa       #");
		System.out.println("################### ##   #");
	}
	
	
}
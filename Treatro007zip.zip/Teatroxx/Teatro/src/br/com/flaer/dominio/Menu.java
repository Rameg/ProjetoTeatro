package br.com.flaer.dominio;

import java.io.Serializable;
import java.util.Scanner;

import br.com.flaer.dominio.Cadeira;	
import br.com.flaer.dominio.Usuario;


/**
 * @author aluno
 *
 */
public class Menu implements Serializable {
    
    
    public static void start(){
        System.out.println("Deseja inicializar um arquivo? Digite 'S'");
        Scanner scn = new Scanner(System.in);
       String rec = scn.nextLine();
       if(rec.equals("S") || rec.equals("s") ){
           System.out.println("Digite o nome do arquivo: ");
          String nomeArquivo = scn.nextLine();
          Seriao.carregarLugares(nomeArquivo);
          Seriao.loadClientes(nomeArquivo);
          
       }
    }
    
   public static void exibirMenu(){
       System.out.println("1 – Cadastrar Usuário");
       System.out.println("2 – Consultar Usuário");
       System.out.println("3 – Ocupar lugar");
       System.out.println("4 – Desocupar lugar");
       System.out.println("5 - Exibir lugares vazios");
       System.out.println("6 - Exibir lugares ocupados");
       System.out.println("7 -Encerrar programa.");
    }
   
   public static void receberOpc(Cadeira cad){
       Scanner scn = new Scanner(System.in);
       try {
              int opc = scn.nextInt();
       int opc2;
       
       
       switch(opc){
            case 1:
                Usuario usa = new Usuario();
                Scanner scnU = new Scanner(System.in);
                System.out.println("Digite o nome do usuário: ");
                usa.setNome(scnU.nextLine());
                System.out.println("Digite o cpf do usuário: ");
                usa.setCpf(scnU.nextLine());
                if(!Seriao.testCpf(usa)){
                    Seriao.cadUsuario(usa);
                    System.out.println("Usuário cadastrado com sucesso!");
                }else{
                    System.out.println("Cpf já está em uso");
                    
                }
                break;
                
             case 2: 
                 System.out.println("Digite o cpf do usuário: ");
                 Scanner scnC = new Scanner(System.in);
                    Usuario usaC = Seriao.ConsulteCpf(scnC.nextLine());
                    if(usaC != null){
                        System.out.println("Nome: "+ usaC.getNome());
                        System.out.println("Cpf: "+ usaC.getCpf());
                        System.out.println("Alocação: " + usaC.getPosicao());
                    }else{
                        System.out.println("Usuário não encontrado");
                    }
                 break;
             case 3:
                 System.out.println("Digite o cpf");
                 Scanner recC = new Scanner(System.in);
                 Usuario UsuCad = Seriao.ConsulteCpf(recC.nextLine());
                 if(UsuCad != null){
                     System.out.println("Digite o número do lugar a ser ocupado.");
                
                
                 try {
                     opc2 = scn.nextInt();
                     
                     if(cad.alocaLugar(opc2, UsuCad)){
                     UsuCad.setPosicao(opc2);
                    System.out.println("Cadeira ocupada com sucesso!");
                }else {
                    System.out.println("Cadeira não está disponivel");
                }
                 } catch (Exception e) {
                     System.out.println("Cadeira não está disponivel");
                 }
                 }else{
                     System.out.println("Usuário não cadastrado");
                 }
                
                break;
            case 4:
                System.out.println("Digite o numero da cadeira que deseja desocupar");
                
              
                try {
                    opc2 = scn.nextInt();
                    if(cad.desalocaLugar(opc2)){
                    System.out.println("Cadeira desocupada com sucesso");
                }else{
                    System.out.println("Cadeira já está desocupada");
                }
                } catch (Exception e) {
                    System.out.println("Cadeira não está disponivel");
                }
                break;
            case 5:
                ;
                cad.emptySpot();
                break;
            case 6:
                
                cad.crowdedSpot();
                break;
                
                case 7:
                    System.out.println("Deseja salvar? S/N");
                    Scanner scn2 = new Scanner(System.in);
                String rec = scn2.nextLine();
                if(rec.equals("S") || rec.equals("s")){
                    System.out.println("Digite o nome do arquivo: ");
                    String nomeArquivo = scn2.nextLine();
                    Seriao.serializaClientes(nomeArquivo);
                    Seriao.salvarLugares(nomeArquivo);
       }
                System.exit(0);
                break;
           
            default:
                 System.out.println("Esta opção não é válida");
    }
   
} catch (Exception e) {
           System.out.println("Opção invalida");
       }

   
}
}


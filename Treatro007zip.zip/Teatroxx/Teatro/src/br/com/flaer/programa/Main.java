
package br.com.flaer.programa;

import br.com.flaer.dominio.Cadeira;
import br.com.flaer.dominio.Menu;

public class Main {
    public static void main(String[] args) 
    {
            Menu.start();
            Cadeira cad = new Cadeira ();
            
            while(true){
                
                Menu.exibirMenu();
                Menu.receberOpc(cad);
            }
    }
}

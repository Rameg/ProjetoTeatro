package br.com.flaer.dominio;

public interface Serializable {

}

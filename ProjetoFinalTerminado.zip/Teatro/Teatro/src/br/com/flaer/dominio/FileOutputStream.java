package br.com.flaer.dominio;

public class FileOutputStream {

	public FileOutputStream(String arquivo) {
		// TODO Auto-generated constructor stub
	}

}

package br.com.flaer.dominio;

import java.io.Serializable;
import java.util.Scanner;

import br.com.flaer.dominio.Cadeira;	
import br.com.flaer.dominio.Usuario;
import br.com.flaer.dominio.Cpf;;

/**
 * @author Micael
 * 
 * 
 *
 */
public class Menu implements Serializable {
    
    
   
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2350958047855010016L;
	private static Scanner scn;

	public static void start()
	{
        System.out.println("Digite o caractere(s) para abrir um arquivo ou digite qualquer coisa para passar um novo arquivo");
        scn = new Scanner(System.in);
       String rec = scn.nextLine();
       if(rec.equals("S") || rec.equals("s")){
           System.out.println("Digite o nome do arquivo: ");
          String nomeArquivo = scn.nextLine();
          Seriao.carregarLugares(nomeArquivo);
          Seriao.carregaClientes(nomeArquivo);
            
       }else System.out.println("Arquivo novo, lembre de salvar!");
    }
    

public static void exibirMenu(){
	   System.out.println("----------------------------------");
	   System.out.println("|    TEATRO UM PIOR QUE O OUTRO   |");
	   System.out.println("----------------------------------");
	   System.out.println("|        ESPETACULO EM CARTAZ    | \n|      O PORTUGUÊS BRASILEIRO     |\n|ESTRELANDO JOÃO RAFAEL-LET IT GO| ");
	   System.out.println("----------------------------------");
       System.out.println("1 - CADASTRAR");
       System.out.println("2 - VERIFICAR USUARIO");
       System.out.println("3 - COMPRAR LUGAR ");
       System.out.println("4 - DEIXAR LUGAR");
       System.out.println("5 - EXIBIR LUGARES DISPONIVEIS");
       System.out.println("6 - EXIBIR LUGARES OCUPADOS");
       System.out.println("7 - IR EM BORA DO BRASIL");
    }
   
   public static void receberOpc(Cadeira cad){
       try {
              int opc = extracted().nextInt();
       int opc2;
       
       
       if (opc == 1) {
		Usuario usa = new Usuario();
		Scanner scnU = extracted();
		System.out.println("DIGITE SEU NOME: ");
		usa.setNome(scnU.nextLine());
		System.out.println("DIGITE SEU CPF: ");
		usa.setCpf(scnU.nextLine());
		if(!Seriao.testCpf(usa)){
		    Seriao.cadUsuario(usa);
		    System.out.println("PARABÉNS!!\n CADASTRADO COM SUCESSO!!\n ");
			System.out.println("BEM VINDO AO TEATRO");
		}else{
		    System.out.println("CPF CADASTRADO \n INSIRA OUTRA AÇAO");
		    
		}
	} else if (opc == 2) {
		System.out.println("DIGITE SEU CPF");

		Scanner scnC = extracted();
		Usuario usaC = Seriao.ConsulteCpf(scnC.nextLine());
		if(usaC != null){
		    System.out.println("NOME: "+ usaC.getNome());
		    System.out.println("CPF: "+ usaC.getCpf());
		    System.out.println("LUGAR: " + usaC.getPosicao());
		}else{
		    System.out.println("USUARIO INDISPONIVEL");
		}
	} else if (opc == 3) {
		System.out.println("DIGITE O CPF");
		Scanner recC = extracted();
		Usuario UsuCad = Seriao.ConsulteCpf(recC.nextLine());
		if(UsuCad != null){
		     System.out.println("DIGITE O NUMERO DO LUGAR LOCADO");
		
		
		 try {
		     opc2 = extracted().nextInt();
		     
		     if(!extracted(cad, opc2, UsuCad)){
		     UsuCad.setPosicao(opc2);
		    System.out.println("CADEIRA INDISPONIVEL!");
		}else {
		    System.out.println("CADEIRA LOCADA COM SUCESSO!");
		}
		 } catch (Exception e) {
		     System.out.println("CADEIRA DISPONIVEL!!");
		 }
		 }else{
		     System.out.println("USUARIO NAO CADASTRADO");
		 }
	} else if (opc == 4) {
		System.out.println("DEGITE O NUMERO DA CADEIRA QUE DESEJA DESOCUPAR:");
		try {
		    opc2 = extracted().nextInt();
		    if(!extracted(cad, opc2)){
		    System.out.println("CADEIRA DESOCUPADA!");
		}else{
		    System.out.println("DESCULPE, A CADEIRA JÁ ESTA DESOCUPADA");
		}
		} catch (Exception e) {
		    System.out.println("DESCULPE, CADEIRA INDISPONIVEL");
		}
	} else if (opc == 5) {
		Cadeira.emptySpot();
	} else if (opc == 6) {
		Cadeira.crowdedSpot();
	} else if (opc == 7) {
		System.out.println("Tem desejo de salvar o lindo arquivo?  Digita S(Salva) ou N_QualquerCoisa(Para as montanhas)");
		Scanner scn2 = extracted();
		String rec = scn2.nextLine();
		if(rec.equals("S") || rec.equals("s")){
			System.out.println("DIGITE O NOME DO ARQUIVO: ");
		    String nomeArquivo = scn2.nextLine();
	 
		    	try {
		    	Seriao.clienteseria(nomeArquivo);
		    	Seriao.lugarsave(nomeArquivo);
		    	}catch(Exception e) {
		    		System.out.println("Saiu no try do carrega arquivo");
		    		System.exit(0);
		    	}
      }else System.out.println("\n Saindo... Olha um unicornico Dragão no Cume da Montanha");
		System.exit(0);
	} else {
		System.out.println("\n  NUNCA NEM VI \n\n TENTE NOVAMENTE \n\n");
	}
   
} catch (Exception e) {
           System.out.println("OPERAÇÃO VALIDADA");
       }

   
}

private static boolean extracted(Cadeira cad, int opc2) {
	return Cadeira.desalocaLugar(opc2);
}

private static boolean extracted(Cadeira cad, int opc2, Usuario UsuCad) {
	return Cadeira.alocaLugar(opc2, UsuCad);
}

private static Scanner extracted() {
	return new Scanner(System.in);
}
}


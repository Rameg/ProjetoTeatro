/**
 * 
 */
package br.com.flaer.dominio;

/**
 * @author imati
 *
 */
public class ArrayList {

	public void add(Usuario usuario) {
		// TODO Auto-generated method stub
		
	}

}
